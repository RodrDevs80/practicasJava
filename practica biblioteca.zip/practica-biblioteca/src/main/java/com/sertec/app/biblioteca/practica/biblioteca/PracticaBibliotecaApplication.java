package com.sertec.app.biblioteca.practica.biblioteca;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PracticaBibliotecaApplication {

	public static void main(String[] args) {
		SpringApplication.run(PracticaBibliotecaApplication.class, args);
	}

}
