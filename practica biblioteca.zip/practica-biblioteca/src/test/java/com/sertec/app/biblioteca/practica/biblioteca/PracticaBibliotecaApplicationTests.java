package com.sertec.app.biblioteca.practica.biblioteca;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PracticaBibliotecaApplicationTests {

	@Test
	void contextLoads() {
	}

}
