package com.sertec.clonGoogleBack;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClonGoogleBackApplicationTests {

	@Test
	void contextLoads() {
	}

}
