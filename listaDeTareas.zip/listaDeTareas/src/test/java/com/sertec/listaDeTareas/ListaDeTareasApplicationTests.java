package com.sertec.listaDeTareas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ListaDeTareasApplicationTests {

	@Test
	void contextLoads() {
	}

}
