package com.sertec.listaDeTareas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ListaDeTareasApplication {

	public static void main(String[] args) {
		SpringApplication.run(ListaDeTareasApplication.class, args);
	}

}
