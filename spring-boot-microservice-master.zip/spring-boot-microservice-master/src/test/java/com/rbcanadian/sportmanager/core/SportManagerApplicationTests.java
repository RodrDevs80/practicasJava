package com.rbcanadian.sportmanager.core;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SportManagerApplicationTests {

	@Test
	void contextLoads() {
	}

}
