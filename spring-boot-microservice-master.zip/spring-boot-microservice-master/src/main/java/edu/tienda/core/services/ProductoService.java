package edu.tienda.core.services;

import edu.tienda.core.domain.Producto;

import java.util.List;

public interface ProductoService {

    public List<Producto> getProductos();

    public void saveProducto(Producto producto);
}
