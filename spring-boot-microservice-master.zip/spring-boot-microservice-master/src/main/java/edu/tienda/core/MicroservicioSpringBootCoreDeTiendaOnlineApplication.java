package edu.tienda.core;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroservicioSpringBootCoreDeTiendaOnlineApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroservicioSpringBootCoreDeTiendaOnlineApplication.class, args);
	}

}
